import React from "react";

function Note() {
  return (
    <div className="note">
      <h1> javascript and React-javascript</h1>
      <p>
        This bootcamp is a good experience for us.This was an amazing bootcamp
        taken up by shaurya sinha sir we covered everything from scratch
        including javascript and React.js,html.
      </p>
    </div>
  );
}

export default Note;
